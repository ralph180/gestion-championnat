
from datetime import datetime

from equipe import Equipe
from match import Match
from journee import Journee

from statistiques import calculer_classement
from statistiques import afficher_classement
from statistiques import afficher_statistiques


class Championnat:

    def __init__(self, nom):

        self.nom = nom

        self._equipes = []
        self._matchs = []
        self._historique = []

        self.prochain_id_equipe = 1
        self.prochain_id_joueur = 1
        self.prochain_id_match = 1

    def historique_ajout(self, message):

        self._historique.append({
            "date": datetime.now().isoformat(timespec="seconds"),
            "operation": message
        })

    def trouver_equipe(self, identifiant):

        for equipe in self._equipes:

            if equipe.identifiant == identifiant:
                return equipe

        return None

    def trouver_match(self, identifiant):

        for match in self._matchs:

            if match.identifiant == identifiant:
                return match

        return None

    def ajouter_equipe(self, nom):

        nom = nom.strip()

        if not nom:
            raise ValueError("Nom obligatoire.")

        if self._matchs:
            raise ValueError("Les inscriptions sont fermées.")

        for equipe in self._equipes:

            if equipe.nom.casefold() == nom.casefold():
                raise ValueError("Cette équipe existe déjà.")

        equipe = Equipe(
            self.prochain_id_equipe,
            nom
        )

        self._equipes.append(equipe)

        self.prochain_id_equipe += 1

        self.historique_ajout(
            "Équipe inscrite : " + nom
        )

    def ajouter_joueur(self, id_equipe, nom):

        equipe = self.trouver_equipe(id_equipe)

        if equipe is None:
            raise ValueError("Équipe introuvable.")

        if self._matchs:
            raise ValueError("Les inscriptions sont fermées.")

        equipe.ajouter_joueur(
            self.prochain_id_joueur,
            nom
        )

        self.prochain_id_joueur += 1

        self.historique_ajout(
            "Joueur inscrit : " + nom.strip()
            + " / " + equipe.nom
        )

    def afficher_equipes(self):

        if not self._equipes:
            print("Aucune équipe inscrite.")
            return

        for equipe in self._equipes:
            equipe.afficher()

    def generer_calendrier(self):

        if self._matchs:
            raise ValueError("Le calendrier existe déjà.")

        if len(self._equipes) < 2:
            raise ValueError("Deux équipes minimum.")

        ids = [
            e.identifiant
            for e in self._equipes
        ]

        if len(ids) % 2 == 1:
            ids.append(None)

        nombre = len(ids)

        nouveaux_matchs = []

        prochain_id = self.prochain_id_match

        for numero in range(1, nombre):

            journee = Journee(numero)

            for i in range(nombre // 2):

                a = ids[i]
                b = ids[nombre - 1 - i]

                if a is None or b is None:
                    continue

                match = Match(
                    prochain_id,
                    a,
                    b,
                    numero,
                    f"Journée {numero}"
                )

                journee.ajouter_match(match)

                nouveaux_matchs.append(match)

                prochain_id += 1

            ids = [ids[0], ids[-1]] + ids[1:-1]

        n = len(self._equipes)

        attendu = n * (n - 1) // 2

        if len(nouveaux_matchs) != attendu:
            raise ValueError("Calendrier incorrect.")

        self._matchs = nouveaux_matchs

        self.prochain_id_match = prochain_id

        self.historique_ajout("Calendrier généré")

    def afficher_matchs(self, restants=False):

        if not self._matchs:

            print("Aucun calendrier disponible.")
            return

        noms = {
            e.identifiant: e.nom
            for e in self._equipes
        }

        numeros = sorted({
            m.journee
            for m in self._matchs
        })

        for numero in numeros:

            journee = Journee(numero)

            for match in self._matchs:

                if match.journee == numero:

                    if restants and match.est_joue():
                        continue

                    journee.ajouter_match(match)

            if journee.matchs:
                journee.afficher(noms)

    def saisir_score(self, id_match, score1,
                     score2, correction=False):

        match = self.trouver_match(id_match)

        if match is None:
            raise ValueError("Match introuvable.")

        if match.est_joue() and not correction:

            raise ValueError(
                "Score déjà enregistré. Utilisez la correction."
            )

        if not match.est_joue() and correction:

            raise ValueError("Aucun score à corriger.")

        if match.est_joue():

            ancien = f"{match.score1}-{match.score2}"

        else:

            ancien = "Non joué"

        match.enregistrer_score(score1, score2)

        self.historique_ajout(
            f"Match {id_match} : "
            f"{ancien} -> {score1}-{score2}"
        )

    def classement(self):

        return calculer_classement(
            self._equipes,
            self._matchs
        )

    def afficher_classement(self):

        afficher_classement(
            self._equipes,
            self._matchs
        )

    def statistiques(self):

        afficher_statistiques(
            self._equipes,
            self._matchs
        )

    def rechercher_equipe(self, texte):

        texte = texte.strip().casefold()

        if not texte:
            raise ValueError("Nom obligatoire.")

        trouvees = [
            e for e in self._equipes
            if texte in e.nom.casefold()
        ]

        if not trouvees:
            print("Aucune équipe trouvée.")

        for equipe in trouvees:
            equipe.afficher()

    def afficher_historique(self):

        if not self._historique:
            print("Historique vide.")

        for operation in self._historique:

            print(
                operation["date"],
                operation["operation"]
            )

    def convertir_dict(self):

        return {

            "nom": self.nom,

            "equipes": [
                e.convertir_dict()
                for e in self._equipes
            ],

            "matchs": [
                m.convertir_dict()
                for m in self._matchs
            ],

            "historique": self._historique,

            "prochain_id_equipe":
                self.prochain_id_equipe,

            "prochain_id_joueur":
                self.prochain_id_joueur,

            "prochain_id_match":
                self.prochain_id_match
        }

    @classmethod
    def depuis_dict(cls, donnees):

        c = cls(donnees["nom"])

        c._equipes = [
            Equipe.depuis_dict(e)
            for e in donnees["equipes"]
        ]

        c._matchs = [
            Match.depuis_dict(m)
            for m in donnees["matchs"]
        ]

        c._historique = donnees["historique"]

        c.prochain_id_equipe = donnees["prochain_id_equipe"]

        c.prochain_id_joueur = donnees["prochain_id_joueur"]

        c.prochain_id_match = donnees["prochain_id_match"]

        return c
