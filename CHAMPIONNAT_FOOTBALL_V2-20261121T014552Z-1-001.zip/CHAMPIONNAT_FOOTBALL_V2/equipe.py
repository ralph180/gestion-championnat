
from joueur import Joueur


class Equipe:

    MAX_JOUEURS = 23

    def __init__(self, identifiant, nom):

        if not nom.strip():
            raise ValueError("Nom obligatoire.")

        self.identifiant = identifiant
        self.nom = nom.strip()
        self._joueurs = []

    def ajouter_joueur(self, identifiant, nom):

        nom = nom.strip()

        if not nom:
            raise ValueError("Nom obligatoire.")

        if len(self._joueurs) >= self.MAX_JOUEURS:
            raise ValueError("Effectif maximum atteint.")

        for joueur in self._joueurs:

            if joueur.nom.casefold() == nom.casefold():
                raise ValueError("Joueur déjà inscrit.")

            if joueur.identifiant == identifiant:
                raise ValueError("Identifiant déjà utilisé.")

        joueur = Joueur(identifiant, nom)

        self._joueurs.append(joueur)

    def afficher(self):

        print(f"\nÉquipe {self.identifiant} : {self.nom}")
        print(f"Effectif : {len(self._joueurs)}/23")

        for joueur in self._joueurs:
            joueur.afficher()

    def convertir_dict(self):

        return {
            "id": self.identifiant,
            "nom": self.nom,
            "joueurs": [
                j.convertir_dict()
                for j in self._joueurs
            ]
        }

    @classmethod
    def depuis_dict(cls, donnees):

        equipe = cls(
            donnees["id"],
            donnees["nom"]
        )

        for joueur in donnees["joueurs"]:

            equipe.ajouter_joueur(
                joueur["id"],
                joueur["nom"]
            )

        return equipe
