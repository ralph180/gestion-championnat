
class Joueur:

    def __init__(self, identifiant, nom):

        if not nom.strip():
            raise ValueError("Nom obligatoire.")

        self.identifiant = identifiant
        self.nom = nom.strip()

    def afficher(self):
        print(self.identifiant, "-", self.nom)

    def convertir_dict(self):
        return {
            "id": self.identifiant,
            "nom": self.nom
        }

    @classmethod
    def depuis_dict(cls, donnees):
        return cls(
            donnees["id"],
            donnees["nom"]
        )
