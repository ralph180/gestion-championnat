
class Journee:

    def __init__(self, numero):

        self.numero = numero
        self.matchs = []

    def ajouter_match(self, match):

        for existant in self.matchs:

            equipes = {
                existant.equipe1_id,
                existant.equipe2_id
            }

            if match.equipe1_id in equipes or match.equipe2_id in equipes:

                raise ValueError(
                    "Une équipe joue déjà durant cette journée."
                )

        self.matchs.append(match)

    def afficher(self, noms_equipes):

        print(f"\n--- JOURNÉE {self.numero} ---")

        for match in self.matchs:

            a = noms_equipes[match.equipe1_id]
            b = noms_equipes[match.equipe2_id]

            if match.est_joue():

                score = f"{match.score1} - {match.score2}"

            else:

                score = "À jouer"

            print(
                f"Match {match.identifiant} : "
                f"{a} contre {b} | {score}"
            )
