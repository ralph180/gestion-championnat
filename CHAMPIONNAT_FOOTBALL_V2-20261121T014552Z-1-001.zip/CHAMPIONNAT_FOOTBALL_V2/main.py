
from copy import deepcopy
from sauvegarde import charger, sauvegarder


def demander_entier(message):

    while True:

        try:

            return int(input(message))

        except ValueError:

            print("Veuillez saisir un nombre entier.")


def main():

    try:

        championnat = charger()

    except (ValueError, OSError) as erreur:

        print("Erreur de chargement :", erreur)
        return

    while True:

        print("\n===================================")
        print(" GESTION DU CHAMPIONNAT DE FOOTBALL")
        print("===================================")

        print("1. Ajouter une équipe")
        print("2. Ajouter un joueur")
        print("3. Afficher les équipes")
        print("4. Générer le calendrier")
        print("5. Afficher les matchs")
        print("6. Enregistrer un score")
        print("7. Corriger un score")
        print("8. Afficher le classement")
        print("9. Rechercher une équipe")
        print("10. Afficher les statistiques")
        print("11. Consulter l'historique")
        print("12. Afficher les matchs restants")
        print("0. Quitter")

        choix = input("Votre choix : ").strip()

        modification = choix in (
            "1", "2", "4", "6", "7"
        )

        if modification:

            travail = deepcopy(championnat)

        else:

            travail = championnat

        try:

            if choix == "1":

                nom = input("Nom de l'équipe : ")

                travail.ajouter_equipe(nom)

            elif choix == "2":

                travail.afficher_equipes()

                identifiant = demander_entier(
                    "ID de l'équipe : "
                )

                nom = input("Nom du joueur : ")

                travail.ajouter_joueur(
                    identifiant,
                    nom
                )

            elif choix == "3":

                travail.afficher_equipes()

            elif choix == "4":

                travail.generer_calendrier()

            elif choix == "5":

                travail.afficher_matchs()

            elif choix == "6" or choix == "7":

                travail.afficher_matchs()

                identifiant = demander_entier(
                    "ID du match : "
                )

                score1 = demander_entier(
                    "Buts équipe 1 : "
                )

                score2 = demander_entier(
                    "Buts équipe 2 : "
                )

                travail.saisir_score(
                    identifiant,
                    score1,
                    score2,
                    correction=(choix == "7")
                )

            elif choix == "8":

                travail.afficher_classement()

            elif choix == "9":

                texte = input("Équipe recherchée : ")

                travail.rechercher_equipe(texte)

            elif choix == "10":

                travail.statistiques()

            elif choix == "11":

                travail.afficher_historique()

            elif choix == "12":

                travail.afficher_matchs(restants=True)

            elif choix == "0":

                print("Merci et à bientôt !")
                break

            else:

                print("Choix invalide.")

            if modification:

                sauvegarder(travail)

                championnat = travail

                print("Opération réussie.")
                print("Données sauvegardées.")

        except ValueError as erreur:

            print("Opération refusée :", erreur)

        except OSError as erreur:

            print("Erreur de sauvegarde :", erreur)
            print("Modification non confirmée.")


if __name__ == "__main__":

    main()
