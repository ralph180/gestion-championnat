
class Match:

    def __init__(self, identifiant, equipe1_id,
                 equipe2_id, journee, creneau):

        if equipe1_id == equipe2_id:
            raise ValueError("Équipes identiques.")

        self.identifiant = identifiant
        self.equipe1_id = equipe1_id
        self.equipe2_id = equipe2_id
        self.journee = journee
        self.creneau = creneau

        self.score1 = None
        self.score2 = None

    def est_joue(self):

        return (
            self.score1 is not None
            and self.score2 is not None
        )

    def enregistrer_score(self, score1, score2):

        if type(score1) is not int or type(score2) is not int:
            raise ValueError("Les scores doivent être entiers.")

        if score1 < 0 or score2 < 0:
            raise ValueError("Score négatif interdit.")

        self.score1 = score1
        self.score2 = score2

    def convertir_dict(self):

        return {
            "id": self.identifiant,
            "equipe1_id": self.equipe1_id,
            "equipe2_id": self.equipe2_id,
            "journee": self.journee,
            "creneau": self.creneau,
            "score1": self.score1,
            "score2": self.score2
        }

    @classmethod
    def depuis_dict(cls, donnees):

        match = cls(
            donnees["id"],
            donnees["equipe1_id"],
            donnees["equipe2_id"],
            donnees["journee"],
            donnees["creneau"]
        )

        if donnees["score1"] is not None or donnees["score2"] is not None:

            match.enregistrer_score(
                donnees["score1"],
                donnees["score2"]
            )

        return match
