
import json
import os
import tempfile

from itertools import combinations
from championnat import Championnat


FICHIER = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "donnees.json"
)


def verifier(championnat):

    ids_equipes = [
        e.identifiant
        for e in championnat._equipes
    ]

    ids_joueurs = [
        j.identifiant
        for e in championnat._equipes
        for j in e._joueurs
    ]

    ids_matchs = [
        m.identifiant
        for m in championnat._matchs
    ]

    groupes = [
        (ids_equipes, championnat.prochain_id_equipe),
        (ids_joueurs, championnat.prochain_id_joueur),
        (ids_matchs, championnat.prochain_id_match)
    ]

    for ids, compteur in groupes:

        for identifiant in ids:

            if type(identifiant) is not int or identifiant < 1:
                raise ValueError("Identifiant invalide.")

        if len(ids) != len(set(ids)):
            raise ValueError("Identifiants dupliqués.")

        if type(compteur) is not int:
            raise ValueError("Compteur invalide.")

        if compteur <= max(ids, default=0):
            raise ValueError("Compteur incohérent.")

    noms = [
        e.nom.casefold()
        for e in championnat._equipes
    ]

    if len(noms) != len(set(noms)):
        raise ValueError("Équipes dupliquées.")

    rencontres = set()
    creneaux = set()

    for match in championnat._matchs:

        a = match.equipe1_id
        b = match.equipe2_id

        if a not in ids_equipes or b not in ids_equipes or a == b:
            raise ValueError("Équipes du match invalides.")

        if type(match.journee) is not int or match.journee < 1:
            raise ValueError("Journée invalide.")

        if match.creneau != f"Journée {match.journee}":
            raise ValueError("Créneau invalide.")

        paire = tuple(sorted([a, b]))

        if paire in rencontres:
            raise ValueError("Rencontre répétée.")

        rencontres.add(paire)

        for equipe in (a, b):

            cle = (equipe, match.journee)

            if cle in creneaux:
                raise ValueError("Conflit de calendrier.")

            creneaux.add(cle)

    if championnat._matchs:

        attendues = set(
            combinations(sorted(ids_equipes), 2)
        )

        if rencontres != attendues:
            raise ValueError("Calendrier incomplet.")

    if not isinstance(championnat._historique, list):
        raise ValueError("Historique invalide.")

    for operation in championnat._historique:

        if not isinstance(operation["date"], str):
            raise ValueError("Date invalide.")

        if not isinstance(operation["operation"], str):
            raise ValueError("Opération invalide.")


def sauvegarder(championnat):

    verifier(championnat)

    temporaire = None

    try:

        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=os.path.dirname(FICHIER),
            suffix=".tmp",
            delete=False
        ) as fichier:

            temporaire = fichier.name

            json.dump(
                championnat.convertir_dict(),
                fichier,
                indent=4,
                ensure_ascii=False
            )

        os.replace(temporaire, FICHIER)

    finally:

        if temporaire and os.path.exists(temporaire):

            os.remove(temporaire)


def charger():

    if not os.path.exists(FICHIER):

        return Championnat(
            "Championnat Football UNIQ"
        )

    try:

        with open(
            FICHIER,
            "r",
            encoding="utf-8"
        ) as fichier:

            donnees = json.load(fichier)

        championnat = Championnat.depuis_dict(donnees)

        verifier(championnat)

        return championnat

    except (
        ValueError,
        KeyError,
        TypeError,
        AttributeError
    ) as erreur:

        raise ValueError(
            "Fichier JSON invalide. "
            "Il ne sera pas écrasé. "
            + str(erreur)
        ) from erreur
