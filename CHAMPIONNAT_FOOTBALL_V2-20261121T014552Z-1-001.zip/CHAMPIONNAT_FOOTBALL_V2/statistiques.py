
def calculer_classement(equipes, matchs):

    tableau = {}

    for equipe in equipes:

        tableau[equipe.identifiant] = {
            "nom": equipe.nom,
            "J": 0,
            "G": 0,
            "N": 0,
            "P": 0,
            "BP": 0,
            "BC": 0,
            "Diff": 0,
            "Pts": 0
        }

    for match in matchs:

        if not match.est_joue():
            continue

        a = tableau[match.equipe1_id]
        b = tableau[match.equipe2_id]

        a["J"] += 1
        b["J"] += 1

        a["BP"] += match.score1
        a["BC"] += match.score2

        b["BP"] += match.score2
        b["BC"] += match.score1

        if match.score1 > match.score2:

            a["G"] += 1
            b["P"] += 1
            a["Pts"] += 3

        elif match.score1 < match.score2:

            b["G"] += 1
            a["P"] += 1
            b["Pts"] += 3

        else:

            a["N"] += 1
            b["N"] += 1

            a["Pts"] += 1
            b["Pts"] += 1

    for ligne in tableau.values():

        ligne["Diff"] = ligne["BP"] - ligne["BC"]

    return sorted(
        tableau.values(),
        key=lambda x: (
            -x["Pts"],
            -x["Diff"],
            -x["BP"],
            x["nom"]
        )
    )


def afficher_classement(equipes, matchs):

    classement = calculer_classement(equipes, matchs)

    print("\n===== CLASSEMENT GÉNÉRAL =====")

    print(
        f"{'Équipe':18} {'J':>2} {'G':>2} "
        f"{'N':>2} {'P':>2} {'BP':>3} "
        f"{'BC':>3} {'Diff':>5} {'Pts':>4}"
    )

    precedent = None

    for ligne in classement:

        criteres = (
            ligne["Pts"],
            ligne["Diff"],
            ligne["BP"]
        )

        egalite = "=" if criteres == precedent else ""

        print(
            f"{ligne['nom'][:18]:18} "
            f"{ligne['J']:>2} "
            f"{ligne['G']:>2} "
            f"{ligne['N']:>2} "
            f"{ligne['P']:>2} "
            f"{ligne['BP']:>3} "
            f"{ligne['BC']:>3} "
            f"{ligne['Diff']:>5} "
            f"{ligne['Pts']:>4} {egalite}"
        )

        precedent = criteres

    print("= : égalité persistante avec l'équipe précédente")


def afficher_statistiques(equipes, matchs):

    joues = [m for m in matchs if m.est_joue()]

    buts = sum(
        m.score1 + m.score2
        for m in joues
    )

    moyenne = buts / len(joues) if joues else 0

    print("\n===== STATISTIQUES =====")

    print("Nombre d'équipes :", len(equipes))
    print("Nombre de matchs :", len(matchs))
    print("Matchs joués :", len(joues))
    print("Matchs restants :", len(matchs) - len(joues))
    print("Total des buts :", buts)
    print("Moyenne de buts :", round(moyenne, 2))
